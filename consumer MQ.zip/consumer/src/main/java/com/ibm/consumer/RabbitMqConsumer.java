package com.ibm.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitMqConsumer {

	public static void main(String[] args) {
		SpringApplication.run(RabbitMqConsumer.class, args);
	}

	@RabbitListener(queues = "tasks")
	public void consume(String message)
	{
		System.out.println("=========****=========");
		System.out.println(message);
		System.out.println("=========****=========");
		
	}
}
