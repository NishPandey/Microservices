package com.ibm.hello.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class myHello {

    public myHello(){
        System.out.println("MyHello object created!" +this.message+ "::::"+this.hashCode());
    }
    @Value("${message}")
    private String message;

    public String getMessage(){
        return message;
    }

}

