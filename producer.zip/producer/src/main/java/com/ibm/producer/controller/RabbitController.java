package com.ibm.producer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RabbitController {

	@Autowired
	HelloService helloService;
	
	@GetMapping
	public void publish(@RequestParam String queuename, @RequestParam String message)
	{		
		System.out.println(queuename);
		System.out.println(message);
		helloService.publish(queuename, message);
	}
}

