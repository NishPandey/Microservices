package com.ibm.hello_web.model;

public class Hello {

}
