package com.ibm.hello_web.controller;

public class HelloControllerTests {

}
